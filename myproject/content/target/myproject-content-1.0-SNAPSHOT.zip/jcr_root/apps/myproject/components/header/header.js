"use strict"; use(function () {
var header = {};
    header.bgcolor = "#"+granite.resource.properties["bgColor"] || "#FFFFFF";
return header; });