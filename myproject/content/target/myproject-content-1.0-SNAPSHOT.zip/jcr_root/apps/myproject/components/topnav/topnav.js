use(function() {
    return {
        root: currentPage.getAbsoluteParent(4)
    };
});