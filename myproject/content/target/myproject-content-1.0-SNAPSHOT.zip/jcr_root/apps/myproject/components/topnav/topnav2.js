"use strict"; use(function () {
var topnav = {};
    topnav.textcolor = "#"+granite.resource.properties["toolbarcolortext"] || "#FFFFFF";
    topnav.bgcolor = "#"+granite.resource.properties["toolbarbgcolor"] || "#2447A6";
return topnav; });


